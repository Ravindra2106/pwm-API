
import authRoutes  from "../routes/auth.router";          
export default[  ...authRoutes];