export class Constants {
    static DB_NAME = process.env.DB_NAME;
    static SERVER = 'server';
    static SERVER_ERROR_MSG = 'Internal Server Error';

    static news = 'SELECT * FROM slambook.authentication'
  }